#实验第二部分

##实验目的
实现一个简单的使用nsfilter的抓包器，抓取http内容里的关键字段，如抓取用户名和密码(比如遇到username:，password:,就抓取)。
